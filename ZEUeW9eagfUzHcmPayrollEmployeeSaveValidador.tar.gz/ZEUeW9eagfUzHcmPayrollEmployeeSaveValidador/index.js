
/**
 * Nome da primitiva : employeeSave
 * Nome do dominio : hcm
 * Nome do serviço : payroll
 * Nome do tenant : trn21163359
 **/
 
const axios = require('axios');

exports.handler = async (event) => {
  
    let body = parseBody(event);
    let tokenSeniorX = event.headers['X-Senior-Token'];
    
    const instance = axios.create({
        baseURL: 'https://platform-homologx.senior.com.br/t/senior.com.br/bridge/1.0/rest/',
        headers: {
          'Authorization': tokenSeniorX
        }
    });
    
    // Exercicio desenvolvido na aula - mantive para exemplo dos demais testes
    if (body.sheetPersona.nickname){
      if (body.sheetPersona.nickname.length > 10 ){
        return sendRes(400,'Apelido deve ter no máximo 10 caracteres')
      }
    } else {
      return sendRes(400,'Apelido deve ser informado')
    }
    
    
    
    // Testes solicitados para a apresentação
    
    // Tema livre - nok
    
    // Exercicio 4 - para contrato do tipo a escala deve ser de 1 a 10 e o tipo permanente
    
    // a condição só será testada se o tipo de colaborador existe e é igual a 1 empregado
    if ((body.sheetContract.employeeType.key) && (body.sheetContract.employeeType.key == 'EMPLOYEE')){
      let escala = await instance.get(`/hcm/payroll/entities/workshift/${body.sheetWorkSchedule.workshift.tableId}`); // busca as informações da escala
      if (escala.data.code >= 10){
        return sendRes(400,'Para funcionários a escala deve estar entre 1 e 10!'); 
      }
      if (escala.data.workshiftType !== "Permanent"){
        return sendRes(400,'Apenas escalas permanentes são permtidas para funcionários'); 
      }
    }
    
    // Exercicio 3 - Não Permitir alteração do nome
    if(body.sheetInitial.employee) { // é alteração de colaborador existente
      
      // busca informações do colaborador antes da alteração
      let empregado = await instance.get(`/hcm/payroll/entities/employee/${body.sheetInitial.employee.tableId}`);
      let primeiroNome =  empregado.data.person.firstname;
      let nomeMeio = empregado.data.person.middlename; 
      let ultimoNome = empregado.data.person.lastname; 
      
      
      // armazena em nome completo o primeiro nome e concatena os outros caso eles não sejam vazios
      let nomeCompleto = primeiroNome;
    
      if(nomeMeio){
        nomeCompleto = nomeCompleto + " " + nomeMeio; 
      }
      if(ultimoNome){
        nomeCompleto = nomeCompleto + " " + ultimoNome; 
      }
        
      if(nomeCompleto !== body.sheetInitial.person.name){
        return sendRes(400,'Não é permitido alterar o nome do colaborador, nome original: ' + nomeCompleto + ' / Novo nome '+ body.sheetInitial.person.name); 
      }
      
    }
    
    // Exercicio 2 - não permitir realizar uma Admissão com o campo "Indicativo de Admissão" com o valor diferente de "Normal".
    if (body.sheetContract.admissionOriginType.key !== "NORMAL"){
        return sendRes(400,'Campo "Indicativo de Admissão" com o valor diferente de "Normal!'); 
    }
    
    // Exercicio 1 - Exige matricula preenchida
    if(!body.sheetContract.registernumber){
        return sendRes(400,'O campo matrícula do colaborador deve ser informado!');
    } 
    
    
    // caso de sucesso
    return sendRes(200, JSON.parse(event.body));
};

const parseBody = (event) => {
  return typeof event.body == 'string' ? JSON.parse(event.body) : event.body || {};
};

const sendRes = (status,body) => {
  var response = {
    statusCode: status,
    headers: {
      "Content-Type": "application/json"
    },
    body: typeof body === 'string' ? body : JSON.stringify(body)
  };
  return response;
}